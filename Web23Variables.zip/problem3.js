let name = "Abhijeet Sen Gupta";
let age = "23"
console.log(name,age)