let name = "Abhijeet Sen Gupta";
console.log(name);
name = "Devdutta Sen Gupta";
console.log(name);
name = "Mousumi Sen Gupta";
console.log(name);